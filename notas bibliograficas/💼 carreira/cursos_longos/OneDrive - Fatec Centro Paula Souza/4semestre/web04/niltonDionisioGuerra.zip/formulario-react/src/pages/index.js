import {useState,useEffect} from 'react'
import Head from 'next/head'
import Image from 'next/image'
import { Inter } from 'next/font/google'
import styles from '@/styles/Home.module.css'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {

  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')


const [loginState,setLoginState] = useState({
  email:'',
  password:'',
})

const [search,setSearch] = useState('')


useEffect(()=>{
  if(search.length > 2){
    console.log(`Realizando busca para '${search}'`)
  }  
},[search])





  const handleChangeLogin = (event,key) => {
    setLoginState({...loginState,[key]:event.target.value})
  }



  const handleSignupForm = (event) => {
    event.preventDefault() 
    console.log({name,email,password})
  }


  return (
    <div className={styles.container}>
      <form className={styles.form} onSubmit={handleSignupForm}>
        <h1>Formulario de cadastro</h1>

        <input
          type='text' 
          placeholder='Nome completo' 
          required
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
        
        <input
          type='email' 
          placeholder='E-mail' 
          required
          value={email}
          onChange={(event) => setEmail(event.target.value)}
        />

        <input
          type='password' 
          placeholder='senha' 
          required
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        />

        <button>Enviar</button>
      </form>
          





      <form className={styles.form}>
        <h1>formulario de login</h1>
            <input
                type='email' 
                placeholder='E-mail' 
                required
                value={loginState.email}
                onChange={(event)=> handleChangeLogin(event,'email')}
            />
            <input
                type='password' 
                placeholder='senha' 
                required
                value={loginState.password}
                onChange={(event)=> handleChangeLogin(event,'password')}
            />
            <button type="submit">Entrar</button>
      </form>


      <form className={styles.form}>
        <h1>Formulario de busca</h1>
        <input
          type='text'
          placeholder='Digite sua busca'
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
                
      </form>
    </div>
  )
}
