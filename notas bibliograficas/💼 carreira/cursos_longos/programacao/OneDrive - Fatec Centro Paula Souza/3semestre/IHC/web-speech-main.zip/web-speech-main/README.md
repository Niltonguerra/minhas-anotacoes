# Web Speech API 
Esse é um exemplo de como usar a Web Speech api. Nesse exemplo eu criei um comando de voz que muda o tema de um site. 
Você pode conferir mais detalhes neste vídeo que fiz. 


https://www.youtube.com/watch?v=A6eh8yXiMY8