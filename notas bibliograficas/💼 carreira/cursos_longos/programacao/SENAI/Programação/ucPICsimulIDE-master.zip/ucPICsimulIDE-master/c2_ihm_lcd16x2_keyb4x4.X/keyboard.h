#ifndef KEyBOARD_H
#define KEyBOARD_H

void keyboard_init( void );
unsigned char keyboard( void );

#endif
