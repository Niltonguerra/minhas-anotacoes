#ifndef DISPLAY7SEGMENTOS_H
#define DISPLAY7SEGMENTOS_H

void disp7seg_init( void );
void disp7seg( unsigned char num );

#endif
