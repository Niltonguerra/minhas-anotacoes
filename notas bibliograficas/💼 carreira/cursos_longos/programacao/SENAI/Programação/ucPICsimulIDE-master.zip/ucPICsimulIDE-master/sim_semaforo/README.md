# Semáforo de veículos para via simples

| Figura (a): Semáforo simples |
|:------------------:|
| ![Semáforo Simples](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-semaforo_veiculos/semaforo_veiculos.gif) |


| Figura (b): Semáforo simples com botão de pedestre |
|:------------------:|
| ![Semáforo Simples](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-semaforo_veiculos_pedestres/semaforo_veiculos_pedestres.gif) |
