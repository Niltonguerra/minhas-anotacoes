# Botão pulsador e LED


| Figura (a): Resistor de *Pull-down* | Figura (b): Resistor de *Pull-up* |
|:-------:|:------:|
| ![Resistor de Pull-Up](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-botaoLED/P0102-botaoLED-pullupres.gif)| ![Resistor de Pull-Down](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-botaoLED/P0102-botaoLED-pulldownres.gif)|
