# Display 7 segmentos Catodo Comum

| Figura (a): Contagem hexadecimal |
|:------------------:|
| ![circuito](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-disp7seg/disp7segCont.gif) |
