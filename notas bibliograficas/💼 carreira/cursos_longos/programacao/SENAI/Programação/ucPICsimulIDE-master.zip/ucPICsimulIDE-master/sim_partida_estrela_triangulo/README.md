# Partida Estrela-Triângulo para motor trifásico

| Figura (a): Partida Estrela-Triângulo |
|:------------------:|
| ![circuito](https://github.com/JoseWRPereira/ddp/blob/master/_posts/tUcPIC/c1-disp7seg/disp7segCont.gif) |
