#ifndef FMM_H
#define FMM_H

#define FMM_VETOR_SIZE  80


void FMM_inserir( char d );
int FMM_media( void );

#endif
