#ifndef PARTIDA_ESTRELA_TRIANGULO_H
#define PARTIDA_ESTRELA_TRIANGULO_H

void pet_init( void );
void pet_k1_set( void );
void pet_k1_reset( void );
void pet_k2_set( void );
void pet_k2_reset( void );
void pet_k3_set( void );
void pet_k3_reset( void );
char pet_s1( void );
char pet_s0( void );

#endif
