#ifndef DELAY_H
#define DELAY_H

#define _XTAL_FREQ  4000000

void delay( unsigned int t );

#endif
